"""
CISA 1360 Demo – Evidence Pack
Goal: show a small, testable program + edge case handling.
"""

def average_score(scores):
    """Return the average of a list of numeric scores."""
    if not scores:
        return None  # edge case: empty list
    return sum(scores) / len(scores)

def main():
    # Happy path
    scores = [72, 85, 90]
    avg = average_score(scores)
    print(f"Scores: {scores}")
    print(f"Average: {avg:.2f}")

    # Edge case
    empty = []
    avg_empty = average_score(empty)
    print(f"Scores: {empty}")
    print(f"Average: {avg_empty}")  # expected: None

if __name__ == "__main__":
    main()
